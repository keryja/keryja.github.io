# Usage

1. Change/remove name
2. Add `Webcam.png` to OBS
2. Resize/crop webcam source to fit (Should be in front of overlay)


# License Info

* [Open Sans](http://www.opensans.com/) font
  by [Steve Matteson](https://en.wikipedia.org/wiki/Steve_Matteson)<br />
  License: [Apache 2.0](http://www.apache.org/licenses/LICENSE-2.0)

* Everything Else
  by [Keryja](http://keryja.tv)<br />
  License: [Creative Commons BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/4.0/)