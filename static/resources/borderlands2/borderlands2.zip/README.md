# Usage

1. Change/remove name
2. Adjust indent if wanted
3. Add `Webcam.png` to OBS
4. Go to webcam filters
5. Add Image Mask/Blend
6. Set type to: Alpha Mask (Color Channel)
7. Browse to 'Webcam Mask.png' for path
8. Resize/crop webcam source to fit (Should be behind overlay)


# License Info

* [WillowBody](http://www.dafont.com/forum/read/160731/borderlands-2-interface-font?highlight=438255#438255) font
  by ???
  License: Unknown

* Everything Else
  by [Keryja](http://keryja.tv)
  License: [Creative Commons BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/4.0/)