# Usage

1. Change/remove name
2. Add `Webcam.png` to OBS
3. Resize/crop webcam source to fit (Should be behind overlay)


# Credits

* [Source Sans Pro](https://www.adobe.com/products/type/font-information/source-sans-pro-readme.html) font
  by [Adobe](https://www.adobe.com)<br />
  License: [Open Font Licese (OFL)](http://wwwimages.adobe.com/content/dam/Adobe/en/products/type/pdfs/eulas/open-font-license.pdf)

* Everything Else
  by [Keryja](http://keryja.tv)<br />
  License: [Creative Commons BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/4.0/)