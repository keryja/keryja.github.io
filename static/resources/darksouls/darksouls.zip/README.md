# Info

* Designed for: 1920x1080


# Usage

2. Add `Deaths.png` OBS
2. Add a text source
3. Set font to Optimus Princeps
4. Set font size to 33
5. Align it to background


# Credits

* [Skull Icon](https://commons.wikimedia.org/wiki/File:Crane_suture_metopique_01_04_2012_1.jpg)
  by [Vassil](https://commons.wikimedia.org/wiki/User:Vassil)<br />
  License: [CC0] (https://creativecommons.org/publicdomain/zero/1.0/deed.en)

* [Optimus Princeps](http://www.dafont.com/optimusprinceps.font) font
  by [Manfred Klein](http://manfred-klein.ina-mar.com/)<br />
  License: [See Site](http://manfred-klein.ina-mar.com/)

* Everything Else
  by [Keryja](http://keryja.tv)<br />
  License: [Creative Commons BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/4.0/)