# Usage

1. Add `Webcam.png` to OBS
2. Resize/crop webcam source to fit (Should be in front of overlay)


# Credits

* Graphics
  by [Keryja](http://keryja.tv)
  License: [Creative Commons BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/4.0/)