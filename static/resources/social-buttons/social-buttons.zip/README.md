# Usage

1. Change Handles
2. Upload To Twitch Panels


# License Info

* [Twitter Bird Icon](https://g.twimg.com/Twitter_logo_blue.png)
  by [Twitter](https://about.twitter.com/press/twitter-brand-policy)<br />
  License: [See Site](https://about.twitter.com/press/twitter-brand-policy)

* [Battle.NET Icon](http://www.easyicon.net/language.en/1107044-battlenet_icon.html) Icon
  by [Unseen Vision](http://www.easyicon.net/language.en/iconsearch/author:Unseen%20Vision/) (Probably Blizzard Though)<br />
  License: Unspecified/free for personal use, see [site](http://www.easyicon.net/language.en/1107044-battlenet_icon.html)

* [Open Sans](http://www.opensans.com/) font
  by [Steve Matteson](https://en.wikipedia.org/wiki/Steve_Matteson)<br />
  License: [Apache 2.0](http://www.apache.org/licenses/LICENSE-2.0)

* Everything Else
  by [Keryja](http://keryja.tv)<br />
  License: [Creative Commons BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/4.0/)