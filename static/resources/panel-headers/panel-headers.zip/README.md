# Usage

1. Create Headers
2. Upload To Twitch


# License Info

* [Optimus Princeps](http://www.dafont.com/optimusprinceps.font) font
  by [Manfred Klein](http://manfred-klein.ina-mar.com/)<br />
  License: [See Site](http://manfred-klein.ina-mar.com/)

* Everything Else
  by [Keryja](http://keryja.tv)<br />
  License: [Creative Commons BY-NC-SA](http://creativecommons.org/licenses/by-nc-sa/4.0/)